<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contrato extends Model
{
	protected $fillable =
	['nu_contrato', 'dt_assinatura', 'vr_financiamento', 'nu_cpf', 'no_mutuario', 'nu_cep', 'no_municipio', 'sg_uf'];
	use HasFactory;
}
