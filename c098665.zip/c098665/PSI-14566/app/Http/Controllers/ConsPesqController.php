<?php
namespace App\Http\Controllers;
use App\Models\Contrato;
use Illuminate\Http\Request;
class ConsPesqController extends Controller
{    
	public function consultarpesquisar()
    {
        $contratos = Contrato::all();
		return view('contratos.consultarpesquisar', compact('contratos'));
    }	
}