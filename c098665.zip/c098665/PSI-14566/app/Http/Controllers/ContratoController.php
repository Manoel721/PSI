<?php
namespace App\Http\Controllers;
use App\Models\Contrato;
use Illuminate\Http\Request;
use DateTime;
use Illuminate\Database\QueryException;

class ContratoController extends Controller
{
	public function index()
    {
        $contratos = Contrato::all();
        return view('contratos.index', compact('contratos'));
    }
    public function create()
    {
        return view('contratos.create');
    }
	public function updateDateColumn(Request $request)
	{
		$dataInicial = $request->input('dt_assinatura');
		$timestamp = strtotime($dataInicial);
		$dataAdaptada = date("d/m/Y", $timestamp);
		//Faz o update no Sqlite da data para o formato da especificação conforme arquivo base_03.csv
		Contrato::where('dt_assinatura', $dataInicial)->update(['dt_assinatura'=>$dataAdaptada]);		
	}
    public function store(Request $request)
    {	
		$request->validate([
            'nu_contrato' => 'required|unique:contratos',
            'dt_assinatura' => 'required',
            'vr_financiamento' => 'nullable',
			'nu_cpf' => 'required|cpf', //Biblioteca Pt-Br-Validator 
			'no_mutuario' => 'required',
			'nu_cep' => 'required|formato_cep', //Biblioteca Pt-Br-Validator (adaptado para a especificação conforme arquivo base_03.csv)
			'no_municipio' => 'required',
			'sg_uf' => 'required',
        ]);
					
		Contrato::create($request->all());
		
		$this->updateDateColumn($request);
		return redirect()->route('contratos.index')->with('success', 'Contrato criado com sucesso.');
    }
	
    public function show(Contrato $contrato)
    {
        return view('contratos.show', compact('contrato'));
    }
    public function edit(Contrato $contrato)
    {
        return view('contratos.edit', compact('contrato'));
    }
	
	public function consultarpesquisar()
    {
        $contratos = Contrato::all();
		return view('contratos.consultarpesquisar', compact('contrato'));
    }
	
    public function update(Request $request, Contrato $contrato)
    {		
		$request->validate([
            'dt_assinatura' => 'required',
            'vr_financiamento' => 'nullable',
			'nu_cpf' => 'required|cpf', //Biblioteca Pt-Br-Validator  
			'no_mutuario' => 'required',
			'nu_cep' => 'required|formato_cep', //Biblioteca Pt-Br-Validator (adaptada para a especificação conforme arquivo base_03.csv)
			'no_municipio' => 'required',
			'sg_uf' => 'required',
        ]);
		
        $contrato->update($request->all());
		
		$this->updateDateColumn($request);		
        return redirect()->route('contratos.index')->with('success', 'Contrato atualizado com sucesso.');
    }
    public function destroy(Contrato $contrato)
    {
        $contrato->delete();
        return redirect()->route('contratos.index')->with('success', 'Contrato removido com sucesso.');
    }
}