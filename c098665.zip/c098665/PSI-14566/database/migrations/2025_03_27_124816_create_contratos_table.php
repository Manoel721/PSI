<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContratosTable extends Migration
{
    public function up()
    {
        Schema::create('contratos', function (Blueprint $table) {
            $table->id();

			$table->INTEGER('nu_contrato')->PRIMARYKEY();
			$table->INTEGER('dt_assinatura');
			$table->TEXT('vr_financiamento');
			$table->TEXT('pc_juros')->nullable();
			$table->INTEGER('pz_carencia')->nullable();
			$table->TEXT('no_mutuario')->nullable();
			$table->TEXT('nu_cpf');
			$table->TEXT('sg_uf')->nullable();
			$table->TEXT('no_municipio')->nullable();
			$table->TEXT('ed_residencial')->nullable();
			$table->TEXT('nu_cep')->nullable();

			$table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('contratos');
    }
}