

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1>Exibir detalhes</h1>
            <div class="card">
                <div class="card-header">
                    <h2><?php echo e($contrato->nu_contrato); ?></h2>
                </div>
                <div class="card-body">
                    <p><strong>Data de assinatura:</strong> <?php echo e($contrato->dt_assinatura); ?></p>
                    <p><strong>Valor de financiamento:</strong> <?php echo e($contrato->vr_financiamento); ?></p>
					<p><strong>CPF:</strong> <?php echo e($contrato->nu_cpf); ?></p>
					<p><strong>Nome do mutuario:</strong> <?php echo e($contrato->no_mutuario); ?></p>
					<p><strong>CEP:</strong> <?php echo e($contrato->nu_cep); ?></p>
					<p><strong>Município:</strong> <?php echo e($contrato->no_municipio); ?></p>
					<p><strong>UF:</strong> <?php echo e($contrato->sg_uf); ?></p>
                    <a href="<?php echo e(route('contratos.index')); ?>" class="btn btn-secondary">Voltar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PSI\PSI-14566\resources\views/contratos/show.blade.php ENDPATH**/ ?>