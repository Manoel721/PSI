

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1>Inserir contrato</h1>
			<?php if($errors->any()): ?>
				<div class="errors">
				<ul>
					<?php $__currentLoopData = $errors->default->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error[0]); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
				</div>
			<?php endif; ?>
            <form id="formulario" action="<?php echo e(route('contratos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nu_contrato">Número do contrato</label>
                    <input type="number" name="nu_contrato" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="dt_assinatura">Data de assinatura</label>
                    <input type="date" id="dt_assinatura" name="dt_assinatura" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="vr_financiamento">Valor de financiamento</label>
                    <input type="number"  name="vr_financiamento" class="form-control" step="0.01" required>
                </div>
				
				<div class="form-group">
                    <label for="nu_cpf">CPF</label>
                    <input type="text" id="nu_cpf" name="nu_cpf" class="form-control" required>
                </div>
				
				<div class="form-group">
                    <label for="no_mutuario">Nome do mutuário</label>
                    <input type="text"  name="no_mutuario" class="form-control" required>
                </div>
				
					
				<div class="form-group">
                    <label for="nu_cep">CEP</label>
                    <input type="text"  id="nu_cep" name="nu_cep" class="form-control" required>
                </div>
				
				<div class="form-group">
                    <label for="no_municipio">Municipio</label>
                    <input type="text"  name="no_municipio" class="form-control" required>
                </div>
				
				<div class="form-group">
                    <label for="sg_uf">UF</label>
                    <input type="text"  name="sg_uf" class="form-control" required>
                </div>				
				
				
                <button type="submit" class="btn btn-primary">Inserir</button>
            </form>
			<script src="<?php echo e(asset('js/validaCPF.js')); ?>"></script> <!-- O CPF também é validado no servidor (via PHP)-->
			<script src="<?php echo e(asset('js/validaCEP.js')); ?>"></script> <!-- O CEP também é validado no servidor (via PHP)-->
			<script type="text/javascript">
				let inputDate = new Date();
				console.log(inputDate);
				document.querySelector(
				"#dt_assinatura"
				).valueAsDate = inputDate;				
			</script>
        </div>
    </div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PSI\c098665\PSI-14566\resources\views/contratos/create.blade.php ENDPATH**/ ?>