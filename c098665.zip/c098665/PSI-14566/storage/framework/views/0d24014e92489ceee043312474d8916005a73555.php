

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Contratos</h1>
            <a href="<?php echo e(route('contratos.create')); ?>" class="btn btn-primary">Inserir novo contrato</a>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success mt-2">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($error); ?><br/>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <table class="table table-bordered mt-2">
                <tr>
                    <th>Número do contrato</th>
                    <th>Data de assinatura</th>
                    <th>Valor de financiamento</th>
					<th>CPF</th>
					<th>Nome do mutuário</th>
					<th>CEP</th>
					<th>Municipio</th>
					<th>UF</th>
                    <th width="280px">Ação</th>
                </tr>
                <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contrato->nu_contrato); ?></td>
                    <td><?php echo e($contrato->dt_assinatura); ?></td>
                    <td><?php echo e($contrato->vr_financiamento); ?></td>
					<td><?php echo e($contrato->nu_cpf); ?></td>
					<td><?php echo e($contrato->no_mutuario); ?></td>
					<td><?php echo e($contrato->nu_cep); ?></td>
					<td><?php echo e($contrato->no_municipio); ?></td>
					<td><?php echo e($contrato->sg_uf); ?></td>
                    <td>
                        <form action="<?php echo e(route('contratos.destroy', $contrato->id)); ?>" method="POST">
                            <a class="btn btn-info" href="<?php echo e(route('contratos.show', $contrato->id)); ?>">Exibir</a>
                            <a class="btn btn-primary" href="<?php echo e(route('contratos.edit', $contrato->id)); ?>">Editar</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Remover</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
	<div class="row">
	<a href="<?php echo e(route('contratos.consultarpesquisar')); ?>" class="btn btn-secondary">Consultar e Pesquisar</a>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PSI\PSI-14566\resources\views/contratos/index.blade.php ENDPATH**/ ?>