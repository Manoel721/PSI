

<?php $__env->startSection('content'); ?>

<head>
	<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Contratos</h1>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success mt-2">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
			
			<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Filtrar por nº de contrato" title="Digite o número do contrato">
            <table class="table table-striped" id="myTable">
                <tr>
                    <th>Número do contrato</th>
                    <th>Data de assinatura</th>
                    <th>Valor de financiamento</th>
					<th>CPF</th>
					<th>Nome do mutuário</th>
					<th>CEP</th>
					<th>Municipio</th>
					<th>UF</th>
                </tr>
                <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contrato->nu_contrato); ?></td>
                    <td><?php echo e($contrato->dt_assinatura); ?></td>
                    <td><?php echo e($contrato->vr_financiamento); ?></td>
					<td><?php echo e($contrato->nu_cpf); ?></td>
					<td><?php echo e($contrato->no_mutuario); ?></td>
					<td><?php echo e($contrato->nu_cep); ?></td>
					<td><?php echo e($contrato->no_municipio); ?></td>
					<td><?php echo e($contrato->sg_uf); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
			<script src="<?php echo e(asset('js/filtro.js')); ?>"></script>
        </div>
    </div>
	<div class="row">
	<a href="<?php echo e(route('contratos.index')); ?>" class="btn btn-secondary">Voltar</a>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PSI\PSI-14566\resources\views/contratos/consultarpesquisar.blade.php ENDPATH**/ ?>