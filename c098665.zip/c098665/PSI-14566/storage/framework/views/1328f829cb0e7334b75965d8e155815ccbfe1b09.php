

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1>Edição individual do contrato</h1>
			<?php if($errors->any()): ?>
				<div class="errors">
				<ul>
					<?php $__currentLoopData = $errors->default->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error[0]); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
				</div>
			<?php endif; ?>
            <form id="formulario" action="<?php echo e(route('contratos.update', $contrato->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="nu_contrato">Número do contrato</label>
                    <input type="number" name="nu_contrato" class="form-control" value="<?php echo e($contrato->nu_contrato); ?>" disabled>
                </div>
                <div class="form-group">
                    <label for="dt_assinatura">Data de assinatura</label>
					<span><?php echo e($contrato->dt_assinatura); ?></span>
					<input type="date" name="dt_assinatura" class="form-control" value="<?php echo e(Carbon\Carbon::createFromFormat('d/m/Y', $contrato->dt_assinatura)->format('Y-m-d')); ?>" required>
					
                </div>
                <div class="form-group">
                    <label for="vr_financiamento">Valor de financiamento</label>
                    <input type="number"  name="vr_financiamento" class="form-control" step="0.01" value="<?php echo e($contrato->vr_financiamento); ?>" required>
                </div>
				
				<div class="form-group">
                    <label for="nu_cpf">CPF</label>
                    <input type="text" id="nu_cpf" name="nu_cpf" class="form-control" value="<?php echo e($contrato->nu_cpf); ?>" required>
                </div>
				
				<div class="form-group">
                    <label for="no_mutuario">Nome do mutuário</label>
                    <input type="text"  name="no_mutuario" class="form-control" value="<?php echo e($contrato->no_mutuario); ?>" required>
                </div>
							
				<div class="form-group">
                    <label for="nu_cep">CEP</label>
                    <input type="text" id="nu_cep" name="nu_cep" class="form-control" value="<?php echo e($contrato->nu_cep); ?>" required>
                </div>
				
				<div class="form-group">
                    <label for="no_municipio">Municipio</label>
                    <input type="text"  name="no_municipio" class="form-control" value="<?php echo e($contrato->no_municipio); ?>" required>
                </div>
				
				<div class="form-group">
                    <label for="sg_uf">UF</label>
                    <input type="text"  name="sg_uf" class="form-control" value="<?php echo e($contrato->sg_uf); ?>" required>
                </div>

				
				
                <button type="submit" class="btn btn-primary">Editar</button>
            </form>
			<script src="<?php echo e(asset('js/validaCPF.js')); ?>"></script> <!-- O CPF também é validado no servidor (via PHP)-->
			<script src="<?php echo e(asset('js/validaCEP.js')); ?>"></script> <!-- O CEP também é validado no servidor (via PHP)-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PSI\PSI-14566\resources\views/contratos/edit.blade.php ENDPATH**/ ?>