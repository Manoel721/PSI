

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1>Inserir contrato</h1>
            <form action="<?php echo e(route('contratos.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nu_contrato">Número do contrato</label>
                    <input type="text" name="nu_contrato" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="dt_assinatura">Data de assinatura</label>
                    <input type="date" name="dt_assinatura" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="vr_financiamento">Valor de financiamento</label>
                    <input type="text"  name="vr_financiamento" class="form-control" required>
                </div>
				

				
				<div class="form-group">
                    <label for="no_mutuario">Nome do mutuário</label>
                    <input type="text"  name="no_mutuario" class="form-control" required>
                </div>
				
				<div class="form-group">
                    <label for="nu_cpf">CPF</label>
                    <input type="text"  name="nu_cpf" class="form-control" required>
                </div>
					
				<div class="form-group">
                    <label for="nu_cep">CEP</label>
                    <input type="text"  name="nu_cep" class="form-control" required>
                </div>
				
				<div class="form-group">
                    <label for="no_municipio">Municipio</label>
                    <input type="text"  name="no_municipio" class="form-control" required>
                </div>
				
				<div class="form-group">
                    <label for="sg_uf">UF</label>
                    <input type="text"  name="sg_uf" class="form-control" required>
                </div>				
				
				
                <button type="submit" class="btn btn-primary">Inserir</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PSI\PSI-14566\resources\views/contratos/create.blade.php ENDPATH**/ ?>