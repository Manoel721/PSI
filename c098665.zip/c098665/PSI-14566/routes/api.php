<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/',[
    'as' => 'contratos.consultarpesquisar',
    'uses' => 'App\Http\Controllers\ConsPesqController@consultarpesquisar'
]);

Route::post('/create',[
    'as' => 'contratos.methodName',
    'uses' => 'App\Http\Controllers\RequestName@methodName'
]);

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
