<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ContratoController;

Route::resource('contratos', ContratoController::class);

Route::get('/', function () {
    return view('welcome');
});
