function validaCEP(cep) {
	cep = cep.replace(/\D+/g, '');
	if (cep.length !== 8) return false;
	return true;
}

document.addEventListener('DOMContentLoaded', function() {
	document.getElementById('formulario').addEventListener('submit', function(e) {
		var cep = document.getElementById('nu_cep').value;
		if (!validaCEP(cep)) {
			e.preventDefault();
			alert('CEP inválido. Verifique o número digitado. Digite sem ponto e sem traço.');
			document.getElementById('nu_cep').focus();
		}
	});
	
	/*
	--> Sem ponto e sem traço conforme especificação do arquivo base_03.csv
	document.getElementById('nu_cep').addEventListener('input', function(e) {
		var value = e.target.value;
		var cepPattern = value.replace(/\D/g, '')
							  .replace(/(\d{2})(\d)/, '$1.$2')
							  .replace(/(\d{3})(\d)/, '$1-$2');
		e.target.value = cepPattern;
	});
	*/	
});