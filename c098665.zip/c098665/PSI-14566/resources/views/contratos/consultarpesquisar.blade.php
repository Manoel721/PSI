@extends('layouts.app')

@section('content')

<head>
	<link rel="stylesheet" href="{{ asset('css/styles.css') }}">
</head>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Contratos</h1>
            @if ($message = Session::get('success'))
                <div class="alert alert-success mt-2">
                    <p>{{ $message }}</p>
                </div>
            @endif
			
			<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Filtrar por nº de contrato" title="Digite o número do contrato">
            <table class="table table-striped" id="myTable">
                <tr>
                    <th>Número do contrato</th>
                    <th>Data de assinatura</th>
                    <th>Valor de financiamento</th>
					<th>CPF</th>
					<th>Nome do mutuário</th>
					<th>CEP</th>
					<th>Municipio</th>
					<th>UF</th>
                </tr>
                @foreach ($contratos as $contrato)
                <tr>
                    <td>{{ $contrato->nu_contrato }}</td>
                    <td>{{ $contrato->dt_assinatura }}</td>
                    <td>{{ $contrato->vr_financiamento }}</td>
					<td>{{ $contrato->nu_cpf }}</td>
					<td>{{ $contrato->no_mutuario }}</td>
					<td>{{ $contrato->nu_cep }}</td>
					<td>{{ $contrato->no_municipio }}</td>
					<td>{{ $contrato->sg_uf }}</td>
                </tr>
                @endforeach
            </table>
			<script src="{{ asset('js/filtro.js') }}"></script>
        </div>
    </div>
	<div class="row">
	<a href="{{ route('contratos.index') }}" class="btn btn-secondary">Voltar</a>
	</div>
</div>
@endsection

