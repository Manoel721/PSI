@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1>Exibir detalhes</h1>
            <div class="card">
                <div class="card-header">
                    <h2>{{ $contrato->nu_contrato }}</h2>
                </div>
                <div class="card-body">
                    <p><strong>Data de assinatura:</strong> {{ $contrato->dt_assinatura }}</p>
                    <p><strong>Valor de financiamento:</strong> {{ $contrato->vr_financiamento }}</p>
					<p><strong>CPF:</strong> {{ $contrato->nu_cpf }}</p>
					<p><strong>Nome do mutuario:</strong> {{ $contrato->no_mutuario }}</p>
					<p><strong>CEP:</strong> {{ $contrato->nu_cep }}</p>
					<p><strong>Município:</strong> {{ $contrato->no_municipio }}</p>
					<p><strong>UF:</strong> {{ $contrato->sg_uf }}</p>
                    <a href="{{ route('contratos.index') }}" class="btn btn-secondary">Voltar</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection