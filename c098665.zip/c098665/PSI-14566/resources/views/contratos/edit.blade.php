@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h1>Edição individual do contrato</h1>
			@if($errors->any())
				<div class="errors">
				<ul>
					@foreach($errors->default->messages() as $error)
				<li>{{ $error[0] }}</li>
					@endforeach
				</ul>
				</div>
			@endif
            <form id="formulario" action="{{ route('contratos.update', $contrato->id) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="form-group">
                    <label for="nu_contrato">Número do contrato</label>
                    <input type="number" name="nu_contrato" class="form-control" value="{{ $contrato->nu_contrato }}" disabled>
                </div>
                <div class="form-group">
                    <label for="dt_assinatura">Data de assinatura</label>
					<span>{{ $contrato->dt_assinatura }}</span>
					<input type="date" name="dt_assinatura" class="form-control" value="{{ Carbon\Carbon::createFromFormat('d/m/Y', $contrato->dt_assinatura)->format('Y-m-d') }}" required>
					
                </div>
                <div class="form-group">
                    <label for="vr_financiamento">Valor de financiamento</label>
                    <input type="number"  name="vr_financiamento" class="form-control" step="0.01" value="{{ $contrato->vr_financiamento }}" required>
                </div>
				
				<div class="form-group">
                    <label for="nu_cpf">CPF</label>
                    <input type="text" id="nu_cpf" name="nu_cpf" class="form-control" value="{{ $contrato->nu_cpf }}" required>
                </div>
				
				<div class="form-group">
                    <label for="no_mutuario">Nome do mutuário</label>
                    <input type="text"  name="no_mutuario" class="form-control" value="{{ $contrato->no_mutuario }}" required>
                </div>
							
				<div class="form-group">
                    <label for="nu_cep">CEP</label>
                    <input type="text" id="nu_cep" name="nu_cep" class="form-control" value="{{ $contrato->nu_cep }}" required>
                </div>
				
				<div class="form-group">
                    <label for="no_municipio">Municipio</label>
                    <input type="text"  name="no_municipio" class="form-control" value="{{ $contrato->no_municipio }}" required>
                </div>
				
				<div class="form-group">
                    <label for="sg_uf">UF</label>
                    <input type="text"  name="sg_uf" class="form-control" value="{{ $contrato->sg_uf }}" required>
                </div>

				
				
                <button type="submit" class="btn btn-primary">Editar</button>
            </form>
			<script src="{{ asset('js/validaCPF.js') }}"></script> <!-- O CPF também é validado no servidor (via PHP)-->
			<script src="{{ asset('js/validaCEP.js') }}"></script> <!-- O CEP também é validado no servidor (via PHP)-->
        </div>
    </div>
</div>
@endsection