@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Contratos</h1>
            <a href="{{ route('contratos.create') }}" class="btn btn-primary">Inserir novo contrato</a>
            @if ($message = Session::get('success'))
                <div class="alert alert-success mt-2">
                    <p>{{ $message }}</p>
                </div>
            @endif
			@foreach ($errors->all() as $error)
			{{ $error }}<br/>
			@endforeach
            <table class="table table-bordered mt-2">
                <tr>
                    <th>Número do contrato</th>
                    <th>Data de assinatura</th>
                    <th>Valor de financiamento</th>
					<th>CPF</th>
					<th>Nome do mutuário</th>
					<th>CEP</th>
					<th>Municipio</th>
					<th>UF</th>
                    <th width="280px">Ação</th>
                </tr>
                @foreach ($contratos as $contrato)
                <tr>
                    <td>{{ $contrato->nu_contrato }}</td>
                    <td>{{ $contrato->dt_assinatura }}</td>
                    <td>{{ $contrato->vr_financiamento }}</td>
					<td>{{ $contrato->nu_cpf }}</td>
					<td>{{ $contrato->no_mutuario }}</td>
					<td>{{ $contrato->nu_cep }}</td>
					<td>{{ $contrato->no_municipio }}</td>
					<td>{{ $contrato->sg_uf }}</td>
                    <td>
                        <form action="{{ route('contratos.destroy', $contrato->id) }}" method="POST">
                            <a class="btn btn-info" href="{{ route('contratos.show', $contrato->id) }}">Exibir</a>
                            <a class="btn btn-primary" href="{{ route('contratos.edit', $contrato->id) }}">Editar</a>
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Remover</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </table>
        </div>
    </div>
	<div class="row">
	<a href="{{ route('contratos.consultarpesquisar') }}" class="btn btn-secondary">Consultar e Pesquisar</a>
	</div>
</div>
@endsection