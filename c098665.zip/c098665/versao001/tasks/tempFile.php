<?php
include '../db/conndb.php';
$novatarefa=$_POST['unovatarefa'];
$descricao = $_POST['udescricao'];
$data = $_POST['udata'];
$status = $_POST['ustatus'];
$id = $_GET['u_id'];

$query =
"UPDATE user_table SET titulo_tarefa = '$novatarefa', descricao_tarefa = '$descricao', data_vencimento = '$data', status_tarefa = '$status'
WHERE tarefa_id = '$id';";


if ($db->exec($query)) {
    header("Location:../index.php");
    echo "Successfully Insert Records";
} else {
    echo "error with the query";
}
?>