<?php
include '../db/conndb.php';
$uname=$_POST['uname'];
$uemail = $_POST['uemail'];
$udatta = $_POST['udatta'];
$ustatus = $_POST['ustatus'];

$query =
"INSERT INTO user_table(titulo_tarefa, descricao_tarefa, data_vencimento, status_tarefa) VALUES( '$uname', '$uemail', '$udatta', '$ustatus');";
if ($db->exec($query)) {
    header("Location:../index.php");
    //    echo "Successfully Insert Records";
} else {
    echo "error with the query";
}
?>