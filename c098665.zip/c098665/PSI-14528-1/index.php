<?php
        include 'others/header.php';
?>
<div class="container bg-white">
    <?php
    include 'conndb.php';
    $query = "SELECT * FROM tasks";
    $result = $db -> query($query);
    ?>
    <div class="row" style="margin-top: 30px; margin-bottom: 10px;">
        <div class="col-sm-4">
            <h4>Incluir nova tarefa</h4>
            <form action="../form1.php" method="POST">
                <div class="form-group">
                    <label for="unovatarefa" class="text-info">Título da tarefa:</label>
                    <input type="text" class="form-control" name="unovatarefa" required>
                </div>
                <div class="form-group">
                    <label for="udescricao" class="text-info">Descrição:</label>
                    <input type="text" class="form-control" name="udescricao" required>
                </div>
                <div class="form-group">
                    <label for="udatta" class="text-info">Data de vencimento</label>
                    <input type="date" class="form-control" name="udatta" required>
                </div>
                <div class="form-group">                    
                    <label for="ustatus" class="text-info">Status</label>
                    <select id="idstatus" type="text" class="form-control" name="ustatus" required>
                        <option value="pendente" selected>pendente</option>
                        <option value="em progresso">em progresso</option>
                        <option value="concluída">concluída</option>
                    </select>
                </div>
                <div align="center">
                    <button type="submit" class="btn btn-primary">Inserir Tarefa</button>
                    <a href="../encaminharParaEndpointGet.php" class="btn btn-info" role="button">Acessar o Endpoint "GET"</a>
                </div>
            </form>   
            
        </div>
        <div class="col-sm-8">
            <h4>Relação das tarefas agendadas</h4>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Identificador</th>
                    <th>Tarefa</th>
                    <th>Descrição</th>
                    <th>Data Vencimento</th>
                    <th>Status</th>
                    <th>Opções</th>
                </tr>
                </thead>
                <tbody>
                <?php
                //Here we Read the data base from the variable result
                //while (true)
                //fetchArray return false when there is not more elements in the array
                while ($row = $result->fetchArray()) {
                    ?>
                    <tr>
                        <!-- <td>John</td>-->
                        <td><?php echo $row['tarefa_id']; ?></td>
                        <td><?php echo $row['titulo_tarefa']; ?></td>
                        <td><?php echo $row['descricao_tarefa']; ?></td>
                        <td><?php echo $row['data_vencimento']; ?></td>
                        <td><?php echo $row['status_tarefa']; ?></td>
                        <td>
                            <a href="../encaminharParaEndpointPut.php?u_id=<?php echo $row['tarefa_id'];?>" class="btn btn-info" role="button">Atualizar</a>
                            <a href="../encaminharParaEndpointDel.php?u_id=<?php echo $row['tarefa_id'];?>" class="btn btn-danger" role="button">Deletar</a>
                        </td>
                    </tr>
                    <?php
                }

                ?>
                <?php
                ?>
                </tbody>
            </table>

        </div>


    </div>

</div>


<?php include 'others/footer.php' ?>

