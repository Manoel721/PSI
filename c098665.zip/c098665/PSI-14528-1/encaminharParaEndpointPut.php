<?php
include 'conndb.php';
$id = $_GET['u_id'];
//echo ($id);
$query = "SELECT * FROM tasks WHERE tarefa_id = '$id'";
//echo $query;
$res = $db -> query($query);
//if ($db -> query($query)){
//   echo "delete user success .....";
//}
//else{
//    echo "error in query ...";
//}

include 'others/header.php';
?>
    <div class="container bg-light">
        <h2>Atualizar tarefa:</h2>
        <div class="row" style="margin-top:19px; margin-bottom: 10px;">
            <div class="col-sm-6">
                <form action="../form2.php?u_id=<?php echo $id;?>" method="POST">
                    <?php
                    while ($row = $res->fetchArray())
                    {
                    ?>
                    <input type="hidden" name="id" value="<?php echo $row['tarefa_id']; ?>">
                    <div class="form-group">
                        <label for="unovatarefa" class="text-info">Título da tarefa:</label>
                        <input type="text" class="form-control" name="unovatarefa" value="<?php echo $row['titulo_tarefa']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="udescricao" class="text-info">Descrição:</label>
                        <input type="text" class="form-control" name="udescricao" value="<?php echo $row['descricao_tarefa']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="udatta" class="text-info">Data Vencimento</label>
                        <input type="date" class="form-control" name="udatta" value="<?php echo $row['data_vencimento']; ?>">
                    </div>
                    <div class="form-group">                    
                    <label for="ustatus" class="text-info">Status</label>
                    <select id="idstatus" type="text" class="form-control" name="ustatus" value="<?php echo $row['status_tarefa']; ?>">
                        <option value="pendente" selected>pendente</option>
                        <option value="em progresso">em progresso</option>
                        <option value="concluída">concluída</option>
                    </select>
                </div>
                    <?php
                    }
                    ?>
                    <div align="center">
                        <button type="submit" class="btn btn-danger">Atualizar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
include 'others/footer.php';
?>