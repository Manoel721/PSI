<?php
$db = new SQLite3("C:\\PSI\\PSI-14528-1\\usersb.db");

//if (!$db) {die("db not created .... ");} else {echo "create database successfully";}

//create table in sqlite database
$query = "CREATE TABLE IF NOT EXISTS tasks (tarefa_id integer primary key, 
            titulo_tarefa text, descricao_tarefa text, data_vencimento date, status_tarefa text,
            CHECK (status_tarefa = 'pendente' OR 
                   status_tarefa = 'em progresso' OR
                   status_tarefa = 'concluída')
            )";
$db->exec($query);
?>
