<?php

$id = $_GET['u_id'];
$url = 'http://localhost:8080/PSI14528.php/psi/tasks/'.$id;

ini_set('default_socket_timeout', 2);

$result = file_get_contents($url, false, stream_context_create(array( 'http' => array( 'method' => 'DELETE' ) )));

header('Location: ' . $_SERVER['HTTP_REFERER']);