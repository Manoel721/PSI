<?php

$novatarefa = $_POST['unovatarefa'];
$descricao = $_POST['udescricao'];
$data = $_POST['udatta'];
$status = $_POST['ustatus'];


$url = 'http://localhost:8080/PSI14528.php/psi/tasks';

ini_set('default_socket_timeout', 2);

$parameters = array('titulo_tarefa' => $novatarefa, 'descricao_tarefa' => $descricao, 'data_vencimento' => $data, 'status_tarefa' => $status );
$options = array('http' => array(
    'header'  => 'Content-Type: application/x-www-form-urlencoded\r\n',
    'method'  => 'POST',
    'content' => http_build_query($parameters),
    'ignore_errors' => true
));

$context  = stream_context_create($options);

$result = file_get_contents($url, false, $context);

header('Location: ' . $_SERVER['HTTP_REFERER']);

