<?php

include 'conndb.php';

function CallAPI($method, $url, $data = false)
{
    $curl = curl_init();

    switch ($method)
    {
        case "POST":
            curl_setopt($curl, CURLOPT_POST, 1);

            if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            break;
        case "PUT":
            curl_setopt($curl, CURLOPT_PUT, 1);
            break;
        default:
            if ($data)
                $url = sprintf("%s?%s", $url, http_build_query($data));
    }

    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    $result = curl_exec($curl);

    curl_close($curl);

    return $result;
}

$query = "SELECT tarefa_id FROM tasks";

$res = $db -> query($query);

$vars = [];

while ($vars = $res->fetchArray()) {

$url = 'http://localhost:8080/PSI14528.php/psi/tasks/'.$vars['tarefa_id'];

ini_set('default_socket_timeout', 1);
ini_set('display_errors', 1);  // set to 0 for production version
error_reporting(E_ALL);

$options = array('http' => array(
    'header'  => 'Content-Type: application/json',
    'method'  => 'GET',
    'ignore_errors' => true
));

$context = stream_context_create($options);
//$result = file_get_contents($url, false, $context);
$resposta = CallAPI('GET', $url);

$query = "SELECT * FROM tasks";
$result = $db -> query($query);
}
include 'others/header.php';
?>
<head>
<link rel="stylesheet" href="styles.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
    <div class="container bg-light">
        <div class="row" style="margin-top:19px; margin-bottom: 10px;">
            <div class="col-sm-4">
            <h4>Relação das tarefas agendadas</h4>
            <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Filtrar por status" title="Digite o status">
            <table class="table table-striped" id="myTable">
                <thead>
                <tr class="header">
                    <th>Status</th>
                    <th>Identificador</th>
                    <th>Tarefa</th>
                    <th>Descrição</th>
                    <th>Data Vencimento</th>                    
                </tr>
                </thead>
                <tbody>
                <?php
                //Here we Read the data base from the variable result
                //while (true)
                //fetchArray return false when there is not more elements in the array
                while ($row = $result->fetchArray()) {
                    ?>
                    <tr>
                        <td><?php echo $row['status_tarefa']; ?></td>
                        <td><?php echo $row['tarefa_id']; ?></td>
                        <td><?php echo $row['titulo_tarefa']; ?></td>
                        <td><?php echo $row['descricao_tarefa']; ?></td>
                        <td><?php echo $row['data_vencimento']; ?></td>
                    </tr>
                    <?php
                }
                ?>
                <?php
                ?>
                </tbody>
            </table>
            <script src="filtro.js"></script>
        </div>
    </div>
<?php
include 'others/footer.php';
?>