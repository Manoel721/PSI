<?php
namespace Tqdev\PhpCrudApi {
    include 'api/PhpCrudApi.php';
    use Tqdev\PhpCrudApi\Api;
    use Tqdev\PhpCrudApi\Config\Config;
    use Tqdev\PhpCrudApi\RequestFactory;
    use Tqdev\PhpCrudApi\ResponseUtils;

    $config = new Config([
        'driver' => 'sqlite',
        'address' => 'usersb.db',
        'controllers' => 'records,openapi,status,columns',
        'debug' => true,
        'tables' => 'all',
    ]);
    $request = RequestFactory::fromGlobals();
    $api = new Api($config);
    $response = $api->handle($request);
    ResponseUtils::output($response);
}
?>